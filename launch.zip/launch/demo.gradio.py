import gradio as gr
import onnxruntime as rt
import numpy as np
import cv2
import pandas as pd
from PIL import Image

sess = rt.InferenceSession("/home/aistudio/launch/rtdetr_hgnetv2_x_6x_coco.onnx")

def infer(img, threshold):
    if isinstance(img, str):
        img = cv2.imread('/home/aistudio/launch/'+img)
        org_img = img
    else:
        org_img = img
    im_shape = np.array([[float(img.shape[0]), float(img.shape[1])]]).astype('float32')
    img = cv2.resize(img, (640,640))
    scale_factor = np.array([[float(640/img.shape[0]), float(640/img.shape[1])]]).astype('float32')
    img = img.astype(np.float32) / 255.0
    input_img = np.transpose(img, [2, 0, 1])
    image = input_img[np.newaxis, :, :, :]
    output_dict = ["reshape2_83.tmp_0","tile_3.tmp_0"]
    inputs_dict = {
        'im_shape': im_shape,
        'image': image,
        'scale_factor': scale_factor
    }
    result = sess.run(output_dict, inputs_dict)
    for item in result[0]:
        if item[1] > threshold:
            if item[0] == 0:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (255,0,0), 2)
                cv2.putText(org_img, "pedestrian", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            elif item[0] == 1:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (0,255,0), 2)
                cv2.putText(org_img, "people", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            elif item[0] == 2:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (0,0,255), 2)
                cv2.putText(org_img, "bicycle", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            elif item[0] == 3:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (225,225,0), 2)
                cv2.putText(org_img, "car", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            elif item[0] == 4:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (128,0,128), 2)
                cv2.putText(org_img, "van", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            elif item[0] == 5:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (128,0,128), 2)
                cv2.putText(org_img, "truck", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            elif item[0] == 6:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (128,0,128), 2)
                cv2.putText(org_img, "tricycle", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            elif item[0] == 7:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (128,0,128), 2)
                cv2.putText(org_img, "awning-tricycle", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            elif item[0] == 8:
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (128,0,128), 2)
                cv2.putText(org_img, "bus", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
            else :
                cv2.rectangle(org_img, (int(item[2]), int(item[3])), (int(item[4]), int(item[5])), (128,0,128), 2)
                cv2.putText(org_img, "motor", (int(item[2]), int(item[3])), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255,255,255), 1)
    return org_img

with gr.Blocks() as demo:    
    gr.Markdown("# RT-DETR-X无人机航拍检测")
            
    with gr.Tab("选择测试图片"):
        files = ['car.jpg','pedestrian.jpg','truck.jpg']
        drop_down = gr.Dropdown(choices=files,value=files[0])
        threshold = gr.Slider(0, 1, value=0.4, label="设定阈值")
        button = gr.Button("执行检测",variant="primary")        
        gr.Markdown("## 预测输出")
        out_img = gr.Image()        
        button.click(infer,
                     inputs=[drop_down,threshold],
                     outputs=out_img)
               
    with gr.Tab("上传本地图片"):
        input_img = gr.Image()
        threshold = gr.Slider(0, 1, value=0.4, label="阈值")
        button = gr.Button("执行检测",variant="primary")
        gr.Markdown("## 预测输出")
        out_img = gr.Image()        
        button.click(infer,
                     inputs=[input_img,threshold],
                     outputs=out_img)

demo.launch()
